# Home - Zimbabwe Test IG v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ig-empty/ImplementationGuide/smart.who.int.ig-empty | *Version*:0.1.0 |
| Draft as of 2025-11-12 | *Computable Name*:LabTest |

 This DAK and set of implementation tools are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This WHO **[insert health domain here]** DAK **add content here**

### L1 Narrative guidelines

**[insert content here]**

### L2 Operational guidelines

The L2 **[insert health domain here]** Digital adaptation kit publications and implementations tools can be found here:

* [Published DAK Document]()
* [Link to core data dictionary]()
* [Link to decision support logic]()
* [Link to scheduling logic]()
* [Link to indicators table]()
* [Link to functional and non functional requirements]()

### L3 Machine readable guidelines

The L3 FHIR Implementation Guide for the **[insert health domain here]** SMART Guidelines is yet to be published. Links will be published here as soon as they're available.

### L4 Executable guidelines

Reference implementations representing the L4 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### L5 Dynamic guidelines

Content representing the L5 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### News

### Contact Us

Please let us know about your experience in using the DAK and questions you may have by contacting us at [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)

### License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 IGO License](http://creativecommons.org/licenses/by-nc-sa/3.0/igo/).

![](https://i.creativecommons.org/l/by-nc-sa/3.0/igo/88x31.png)

### Providing Feedback

 Feedback specific to this specification can provided through: 

* Clicking on one of the Feedbacks link to the right of any section header
* Sending an email to [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)
* Creating an issue on GitHub [ig-empty repository](https://github.com/WorldHealthOrganization/ig-empty)

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

### Dependencies

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (smart.who.int.ig-empty.r4)](package.r4.tgz) and [R4B (smart.who.int.ig-empty.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [MaritalStatus](http://terminology.hl7.org/5.5.0/CodeSystem-v3-MaritalStatus.html): [Labpatient](StructureDefinition-Labpatient.md)
* [NullFlavor](http://terminology.hl7.org/5.5.0/CodeSystem-v3-NullFlavor.html): [Labpatient](StructureDefinition-Labpatient.md)


